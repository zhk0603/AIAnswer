﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AIAnswer
{
    public class TesseractSvc : OcrServiceBase
    {
        public override void Init()
        {
            throw new NotImplementedException();
        }

        protected override Problem ProcessCore(Stream stream)
        {
            throw new NotImplementedException();
        }
    }
}
